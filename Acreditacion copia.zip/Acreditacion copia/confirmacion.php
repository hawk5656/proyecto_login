
<!-- Se inicia el login se crea el contenedor -->
<div id="containerlog" class="container jumbotron" style="margin-top:20px;">
            <div class="row">
            
<!-- .............................................Se crea la vista para dispositivos extra small...........................................................-->
                                          
                            <div id="visiblexs" class="visible-xs">
                            	
									<strong>Revisa tu correo electrónico</strong>
                                    
									<p>Hemos enviado un correo electrónico a  Haz clic en el enlace del correo electrónico para restablecer tu contraseña.</p>
                                    
                                    <p>Si no ves el correo electrónico, revisa otros lugares donde podría estar, como tus carpetas de correo no deseado, sociales u otras.</p>

                            </div>
                         
<!-- .............................................Se crea la vista para dispositivos small .............................................................-->
                       
                            <div id="visiblesm" class="visible-sm ">     
                            </div>

<!-- .............................................Se crea la vista para dispositivos Medianos.............................................................-->
        
                            <div id="visiblemd" class="visible-md ">
                            </div>
                            
<!-- .............................................Se crea la vista para dispositivos Pantalla larga.......................................................-->
                            
                             <div id="visiblesm" class="visible-lg">   
                             </div>
 
       		</div>
</div>