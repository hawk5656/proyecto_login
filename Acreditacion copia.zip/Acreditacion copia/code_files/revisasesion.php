<?php
session_start();

if(isset($_SESSION['logged']))
	{
		
	}
else if($_SESSION['logged']== 1)
	{
		
	}

?>