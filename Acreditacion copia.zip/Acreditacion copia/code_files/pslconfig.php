<?php
	define("HOST", "localhost");
	define("USER", "usuario_seguro");
	define("PASS", "ynJaZRbcjTDeSK82");
	define("DB", "escuela");
	
	define("CAN_REGISTER", "any");
	define("DEFAULT_ROLE", "member");
	
	define("SECURE", FALSE);
?>