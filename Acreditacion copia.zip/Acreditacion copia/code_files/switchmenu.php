<?php
session_start();

if()
	{
		$_SESSION
	}


$opcion = $_GET['MENU'];
$menu = $_GET['INC'];


?>