<!DOCTYPE html>
<html lang="es">
<head>
<?php session_start(); ?>
<title>Acreditacion</title>
<?php include_once'../Acreditacion/includes/links.php'; ?>
<?php include_once'../Acreditacion/includes/header/header.php'; ?>
</head>
<body>
<!-- Mensaje de javascript desactivado -->
<div class="centro">
        <noscript>
        	<strong>Por favor activa Javascript</strong>
        </noscript>
</div>
<!-- -->

<?php	  include_once'../Acreditacion/switchmenu.php'; ?>
 
<?php // include_once '../acreditacion/includes/login.php';?>
<?php include_once '../acreditacion/includes/footer/footer.php'; ?>
</body>
</html>