<?php 

// Variables para la conexion 
	
	$user = 'root';
	$password = 'root';
	$db = 'inventory';
	$host = 'localhost';
	$port = 3306;

// Variable del switch
	$opcion = mysql_escape_string($_GET['opcion']);
?>