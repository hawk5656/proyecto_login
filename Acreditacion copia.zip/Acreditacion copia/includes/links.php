<!-- codigo conect -->
<?php
session_start();
	include_once 'code_files/db_connect.php';
	include_once 'code_files/functions.php';
	
	if(isset($_GET['error']))
		
		{
			//echo '<p class="error">Error al logear</p>';
		}
		
?>
		
<!-- Referencia CSS-->
<link rel="stylesheet" href="../Acreditacion/css/bootstrap.css" type="text/css">
<link rel="stylesheet" href="../Acreditacion/css/footer.css" type="text/css" charset="UTF-8">
<link rel="shortcut icon" href="../Acreditacion/img/favicon.ico">
<link rel="stylesheet" href="../Acreditacion/css/login.css" type="text/css" charset="UTF-8">



<!-- Referencia JAVASCRIPT-->
<script src="../Acreditacion/js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="../acreditacion/js/validacion.js" language="javascript"></script>


<!-- parte de codigo cristobal -->
<script type="text/JavaScript" src="js/sha512.js"></script> 
<script type="text/JavaScript" src="js/forms.js"></script>


<!-- Referencia  METADATA-->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    

<!--enlaces PHP -->
<?php
 include_once "../Acreditacion/includes/conexion-SQL/variable.php"; 
 include_once "../Acreditacion/includes/conexion-SQL/conexion.php"; 
 ?>

<!--http://udg.mx/sites/default/files/favicon.ico-->


